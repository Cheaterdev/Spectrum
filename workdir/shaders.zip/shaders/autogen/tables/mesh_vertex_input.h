#pragma once
struct mesh_vertex_input
{
	float3 pos;
	float3 normal;
	float2 tc;
	float4 tangent;

};
