#pragma once
struct Color
{
	float4 color; // float4
	float4 GetColor() { return color; }
};
