#pragma once
struct SkyFace
{
	uint face; // uint
	uint GetFace() { return face; }
};
