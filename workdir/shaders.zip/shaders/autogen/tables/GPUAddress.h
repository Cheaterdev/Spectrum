#pragma once
struct GPUAddress
{
	uint2 data; // uint2
	uint2 GetData() { return data; }
};
