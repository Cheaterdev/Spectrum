#pragma once
struct ShadowPayload
{
	bool hit;

};
