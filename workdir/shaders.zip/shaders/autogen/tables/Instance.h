#pragma once
struct Instance
{
	uint instanceId; // uint
	uint GetInstanceId() { return instanceId; }
};
