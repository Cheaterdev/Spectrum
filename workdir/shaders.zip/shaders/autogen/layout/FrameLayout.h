#pragma once
SamplerState linearSampler:register(s0);
SamplerState pointClampSampler:register(s1);
SamplerState linearClampSampler:register(s2);
SamplerState anisoBordeSampler:register(s3);
SamplerState pointBorderSampler:register(s4);
